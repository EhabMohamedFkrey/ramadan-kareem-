function _0x189c() {
  const _0x9e0a7d = [
    "4wMVhSt",
    "floor",
    "createElement",
    "5012229SkoaTh",
    "13178350yBAhjD",
    "11NTUdCG",
    "9346416EWFlMf",
    "<span>Hours</span></div>",
    "updateTimer()",
    "innerHTML",
    "apr\x202,\x202022\x2000:00:00",
    "5092mNhhKu",
    "373suyOHN",
    "6701070OkUuax",
    "54neYoMY",
    "<span>Sec</span></div>",
    "198712dEtuNj",
    "1189650BpZYnA",
    "<p>Created\x20by\x20<a\x20href=\x27https://elghiati.xyz/\x27\x20target=\x27_blank\x27>Ahmed\x20elghiati</a></p>",
    "getElementById",
    "<div>",
    "<span>Days</span></div>",
    "appendChild",
    "parse",
    "<span>Min</span></div>",
  ];
  _0x189c = function () {
    return _0x9e0a7d;
  };
  return _0x189c();
}
const _0x1f6c4b = _0x1090;
(function (_0x13d224, _0x463d8b) {
  const _0x2f5d90 = _0x1090,
    _0x457434 = _0x13d224();
  while (!![]) {
    try {
      const _0x43be54 =
        (-parseInt(_0x2f5d90(0x18a)) / 0x1) *
          (-parseInt(_0x2f5d90(0x189)) / 0x2) +
        (-parseInt(_0x2f5d90(0x19a)) / 0x3) *
          (parseInt(_0x2f5d90(0x197)) / 0x4) +
        parseInt(_0x2f5d90(0x18b)) / 0x5 +
        parseInt(_0x2f5d90(0x19d)) / 0x6 +
        -parseInt(_0x2f5d90(0x18f)) / 0x7 +
        (-parseInt(_0x2f5d90(0x18e)) / 0x8) *
          (-parseInt(_0x2f5d90(0x18c)) / 0x9) +
        (parseInt(_0x2f5d90(0x19b)) / 0xa) *
          (-parseInt(_0x2f5d90(0x19c)) / 0xb);
      if (_0x43be54 === _0x463d8b) break;
      else _0x457434["push"](_0x457434["shift"]());
    } catch (_0x4c5db3) {
      _0x457434["push"](_0x457434["shift"]());
    }
  }
})(_0x189c, 0xcc9e2);
function updateTimer() {
  const _0x535646 = _0x1090;
  (future = Date[_0x535646(0x195)](_0x535646(0x188))),
    (now = new Date()),
    (diff = future - now),
    (days = Math["floor"](diff / (0x3e8 * 0x3c * 0x3c * 0x18))),
    (hours = Math[_0x535646(0x198)](diff / (0x3e8 * 0x3c * 0x3c))),
    (mins = Math[_0x535646(0x198)](diff / (0x3e8 * 0x3c))),
    (secs = Math[_0x535646(0x198)](diff / 0x3e8)),
    (d = days),
    (h = hours - days * 0x18),
    (m = mins - hours * 0x3c),
    (s = secs - mins * 0x3c),
    (document[_0x535646(0x191)]("timer")["innerHTML"] =
      "<div>" +
      d +
      _0x535646(0x193) +
      _0x535646(0x192) +
      h +
      _0x535646(0x19e) +
      _0x535646(0x192) +
      m +
      _0x535646(0x196) +
      _0x535646(0x192) +
      s +
      _0x535646(0x18d));
}
function _0x1090(_0x24cead, _0x59d772) {
  const _0x189c9c = _0x189c();
  return (
    (_0x1090 = function (_0x1090d0, _0x39c240) {
      _0x1090d0 = _0x1090d0 - 0x186;
      let _0xb8cf0d = _0x189c9c[_0x1090d0];
      return _0xb8cf0d;
    }),
    _0x1090(_0x24cead, _0x59d772)
  );
}
let imp = document[_0x1f6c4b(0x199)]("div");
(imp["className"] = "imp"),
  document["body"][_0x1f6c4b(0x194)](imp),
  (imp[_0x1f6c4b(0x187)] = _0x1f6c4b(0x190)),
  setInterval(_0x1f6c4b(0x186), 0x3e8);

// اي شخص هيزيل الحقوق انا خصيمه امام الله
