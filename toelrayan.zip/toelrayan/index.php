<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/master.css">
    <link rel="stylesheet" href="/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;700;800&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">    
<title>Ramadan Kareem</title>
<link rel="icon" href="/assets/giftbox.png">
</head>
<body>
    <div class="container">
        <div class="main">
            <div class="imgtop">
                <img src="/assets/ramadan.png" alt="">
            </div>
            <div class="remain">
                <h2><i class="fas fa-stopwatch"></i> تبقي علي شهر رمضان الكريم <i class="fas fa-stopwatch"></i></h2>
                <div id="timer"></div>
            </div>
            <div class="logo"><img src="/assets/ramdann.png" alt=""></div>
            <form method="post" action="Ramadan.php">
                <div class="inp"><p><button href="/Ramadan.php">متابعة</button></p>
                    <input type="name" name="n" placeholder="ادخل اسمك هنا" >
                </div>
            </form>
            <div class="svg">
                <svg width="100%" height="100%" id="svg" viewBox="0 0 1440 600" xmlns="http://www.w3.org/2000/svg" class="transition duration-300 ease-in-out delay-150"><path d="M 0,600 C 0,600 0,200 0,200 C 81.36842105263159,211.74162679425837 162.73684210526318,223.48325358851676 258,202 C 353.2631578947368,180.51674641148324 462.42105263157896,125.80861244019135 572,141 C 681.578947368421,156.19138755980865 791.5789473684212,241.2822966507178 893,264 C 994.4210526315788,286.7177033492822 1087.2631578947369,247.06220095693777 1177,226 C 1266.7368421052631,204.93779904306223 1353.3684210526317,202.4688995215311 1440,200 C 1440,200 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="#ffffff88" class="transition-all duration-300 ease-in-out delay-150 path-0"></path><path d="M 0,600 C 0,600 0,400 0,400 C 95.2153110047847,375.2535885167464 190.4306220095694,350.50717703349284 293,372 C 395.5693779904306,393.49282296650716 505.4928229665072,461.2248803827751 602,466 C 698.5071770334928,470.7751196172249 781.5980861244018,412.5933014354068 881,375 C 980.4019138755982,337.4066985645932 1096.1148325358852,320.4019138755981 1192,328 C 1287.8851674641148,335.5980861244019 1363.9425837320573,367.79904306220095 1440,400 C 1440,400 1440,600 1440,600 Z" stroke="none" stroke-width="0" fill="#ffffffff" class="transition-all duration-300 ease-in-out delay-150 path-1"></path></svg>
            </div>
            <div class="back"></div>
        </div>
    </div>
    <audio src="/assets/rmaudio.mpeg" autoplay></audio>
    <script src="js/main.js"></script>
</body>
</html>