<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="هنئ احبابك واصحابك بمناسبة شهر رمضان المبارك">
    <link rel="stylesheet" href="css/master.css">
    <link rel="stylesheet" href="css/rmd.css">
    <link rel="stylesheet" href="css/name.scss">
    <link rel="stylesheet" href="/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;700;800&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">    
<title>Ramadan Kareem</title>
<link rel="icon" href="/assets/giftbox.png">
</head>
<body>
    <div class="container">
        <div class="main">
            <div class="imgtop">
                <img src="/assets/ramadan.png" alt="">
            </div>
            <div class="content">
                <h2>
                <span><?php echo $_POST["n"]; ?></span>
              </h2>
              <p class="ptext">يهنئك بمناسبة شهر رمضان الكريم ويتمني لك شهر مليئ بالخير والاعمال الطيبة ويتمني لك السعادة والتوفيق دائما ويقول لك كل عام وانت بخير</p>
            </div>
            <div class="sharesec">

                <h2 class="sharems"> :ارسلها لاصدقائك وهنئهم عبر</h2>

<div class="btn__container">
    <a href="https://api.whatsapp.com/send?text=*<?php echo $_POST["n"]; ?>* 🌙 أرسل لك مفاجأة 🎁 %0A1. افتح %0A2.  أكتب إسمك 
 %0A هنئ اصدقائك وعائلتك بحلول شهر رمضان المبارك 👇👇👇👇👇👇  https://ramadan.mr-andorid.com" class="btn" target="_blank">
      <i class="fab fa-whatsapp"></i>
      <span>Whatsapp</span>
    </a>
      <a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Framadan.mr-andorid.com" class="btn btn-f" target="_blank">
  <i class="fab fa-facebook"></i>    <span>Facebook</span>
    </a>
  </div>
  
  
            </div>
        </div>
    </div>
    <audio src="/assets/rmaudio.mpeg" autoplay></audio>
    <script src="js/main.js"></script>
</body>
</html>